mkdir -p /tmp/mytar/perl

#=========================================================================================
for file in /opt/perl/perl-compile-modules/*.tar.gz
do 

tar -zxf "$file" -C /tmp/mytar/perl 

done

#========================================================================================
while IFS= read -r line
do 

cd /tmp/mytar/perl/"$line" ; echo -e "n" | perl Makefile.PL;make;make install

done < /opt/perl/perl-6.0-depend.txt 


